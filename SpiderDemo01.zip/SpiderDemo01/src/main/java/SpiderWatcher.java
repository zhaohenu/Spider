import java.util.List;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

/**
 * 监控子节点的变化
 * @author zhao
 *
 */
public class SpiderWatcher implements Watcher {
	
	CuratorFramework client = null;
	List<String> ChiledNode =null;

	public SpiderWatcher() {
		// 获取zk的链接
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);// 获取zk链接的一个重试策略
		// 集群192.168.32.120:2181,192.168.32.121:2181,192.168.32.122:2181
		String zookeeperConnectionString = "192.168.32.120:2181,192.168.32.121:2181,192.168.32.122:2181";// 在此指定zk的节点信息
		int sessionTimeoutMs = 5000; // 连接失效时间 即连接关闭以后 失效的时间 在4秒到40秒之间
		int connectionTimeoutMs = 3000; // 连接超时时间
		client = CuratorFrameworkFactory.newClient(zookeeperConnectionString, sessionTimeoutMs,
				connectionTimeoutMs, retryPolicy);
		client.start();

		// 开始监控
		try {
			//这个监控是单次有效的  如果想重复监控需要再次注册
			ChiledNode = client.getChildren().usingWatcher(this).forPath("/monitor");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	/**
	 * 回调函数  
	 * 当监控节点变化时  该函数会被调用
	 */
	@Override
	public void process(WatchedEvent event) {
		try {
			List<String> newChildNode = client.getChildren().usingWatcher(this).forPath("/monitor");
			for (String node : ChiledNode) {
				if (!newChildNode.contains(node)) {
					System.out.println("节点消失+"+node);
				}				
			}
			for (String node : newChildNode) {
				if (!ChiledNode.contains(node)) {
					System.out.println("节点增加+"+node);
					//TODD 给管理员发短信 
				}
				
			}
			//让每一次的newchildnode都与上次相比较
			this.ChiledNode=newChildNode;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	//监控功能需要一直执行
	public void run() {
		while(true) {
			;
		}
	}
	public static void main(String[] args) {
		SpiderWatcher spiderWatcher = new SpiderWatcher();
		spiderWatcher.run();
	}

}
