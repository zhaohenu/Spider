package jredistest.SpiderDemo01;

import java.net.InetAddress;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs.Ids;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jredistest.SpiderDemo01.domain.Page;
import jredistest.SpiderDemo01.download.Downloadable;
import jredistest.SpiderDemo01.download.HttpclienttableImpl;
import jredistest.SpiderDemo01.process.JDProcessableImpl;
import jredistest.SpiderDemo01.process.Process;
import jredistest.SpiderDemo01.repository.RedisRepositoryImpl;
import jredistest.SpiderDemo01.repository.Repository;
import jredistest.SpiderDemo01.store.ConsoleStoreableImpl;
import jredistest.SpiderDemo01.store.Stroreable;

public class Spider {
	public Spider() {
		//获取zk的链接
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);//获取zk链接的一个重试策略
		//集群192.168.32.120:2181,192.168.32.121:2181,192.168.32.122:2181
		String zookeeperConnectionString ="192.168.32.120:2181,192.168.32.121:2181,192.168.32.122:2181";//在此指定zk的节点信息
		int sessionTimeoutMs = 5000;  //连接失效时间  即连接关闭以后  失效的时间  在4秒到40秒之间
		int connectionTimeoutMs = 3000;  //连接超时时间 
		CuratorFramework client = CuratorFrameworkFactory.newClient(zookeeperConnectionString, sessionTimeoutMs, connectionTimeoutMs, retryPolicy);
		client.start();
		
		try {
			//获取本机IP
			InetAddress localHost = InetAddress.getLocalHost();
			String ip = localHost.getHostAddress();
			//创建子节点 如果父节点不存在的话 直接创建父节点
			client.create()
					.creatingParentsIfNeeded()  //如果父节点不存在则创建父节点
					.withMode(CreateMode.EPHEMERAL)  //创建临时节点
					.withACL(Ids.OPEN_ACL_UNSAFE)
					//每一个节点都是有序的所以各不相同 加上本机IP可以具体分析节点所代表的机器
					.forPath("/monitor/"+ip);//创建子节点
		} catch (Exception e) {
			e.printStackTrace();
		}  

	}
	
	//声明下载功能的接口
	private Downloadable downloadable;
	//声明解析功能的接口
	private Process process;
	//声明存储的接口
	private Stroreable stroreable;
	//声明一个数据仓库queue
	//private Queue<String> queue = new ConcurrentLinkedQueue<String>();
	private Repository repository;
	
	private Logger logger = LoggerFactory.getLogger(Spider.class);
	//创建一个线程池
	ExecutorService threadPool = Executors.newFixedThreadPool(5);
	public void start() {
		check();
		logger.info("开始抓取数据...");
		while(true) {			
			//从队列中取出元素 队列中的该元素就没有了
			final String url = repository.poll();			
			if (url!=null) {
				threadPool.execute(new Runnable() {
					public void run() {
						//下载当前URL页面
						Page page = Spider.this.download(url);
						//解析下载的页面
						Spider.this.process(page);
						//将解析的临时URL存放在list中item
						List<String> urls = page.getUrls();
						for (String nextUrl : urls) {
							//将临时URL迭代存入queue中
							repository.add(nextUrl);
						}
						if (url.startsWith("https://item.jd.com")) {
							//如果是商品详情页面 则调用函数解析
							Spider.this.store(page);
							try {
								//解析页面休眠避免被封IP
								Thread.currentThread().sleep(100);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}});
				
				
			}else {
				logger.info("没有URL了...休息一会吧");
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	private void check() {
		if(process==null) {
			String msg = "请指定解析 实现类";
			logger.error(msg);
			throw new RuntimeException(msg);
		}
		logger.info("=========================配置检查================================");
		logger.info("downloadable的实现类是:{}",downloadable.getClass().getSimpleName());
		logger.info("process的实现类是:{}",process.getClass().getSimpleName());
		logger.info("stroreable的实现类是:{}",stroreable.getClass().getSimpleName());
		logger.info("repository的实现类是:{}",repository.getClass().getSimpleName());
		logger.info("=========================配置检查================================");
	}
	/**
	 * 添加入口URL 即种子URL
	 * @param url
	 */
	public void setSeedUrl(String url) {
		//this.queue.add(url);
		this.repository.add(url);
		
	}
	/**
	 * 根据指定URL获取页面内容
	 * @param url
	 */
	public Page download(String url) {
		return this.downloadable.download(url);	
	}
	
	/**
	 * 解析页面信息
	 * @param page
	 */
	public void process(Page page) {
		this.process.process(page);

	}
	/**
	 * 存储页面信息
	 * @param page
	 */
	public void store(Page page) {
		this.stroreable.store(page);
	}


	public void setDownloadable(Downloadable downloadable) {
		this.downloadable = downloadable;
	}

	public void setProcess(Process process) {
		this.process = process;
	}


	public void setStroreable(Stroreable stroreable) {
		this.stroreable = stroreable;
	}

	public void setRepository(Repository repository) {
		this.repository = repository;
	}
	public static void main(String[] args) {
		Spider spider = new Spider();
		//String url="https://list.jd.com/list.html?cat=9987,653,655";		
		//給downloadable接口赋予一个实现类
		spider.setDownloadable(new HttpclienttableImpl());	
		//给解析接口设置实现类
		spider.setProcess(new JDProcessableImpl());
		//给存储接口赋予一个实现类
		spider.setStroreable(new ConsoleStoreableImpl());
		//给Redis一个实现类
		spider.setRepository(new RedisRepositoryImpl());
		
		//spider.setSeedUrl(url);
		
		spider.start();
	}
}
