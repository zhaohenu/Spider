package jredistest.SpiderDemo01.process;

import jredistest.SpiderDemo01.domain.Page;

public interface Process {
	void process(Page page);

}
