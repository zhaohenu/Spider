package jredistest.SpiderDemo01.process;

import org.htmlcleaner.HtmlCleaner;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.htmlcleaner.TagNode;
import org.htmlcleaner.XPatherException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import jredistest.SpiderDemo01.domain.Page;
import jredistest.SpiderDemo01.utils.Htmlutils;
import jredistest.SpiderDemo01.utils.PageUtils;

public class JDProcessableImpl implements Process{

	@Override
	public void process(Page page) {
		HtmlCleaner htmlCleaner = new HtmlCleaner();
		//解析整个页面 tagnode获取整个页面的父节点 然后进行页面解析操作
		TagNode rootNode = htmlCleaner.clean(page.getContent());
		if(page.getUrl().startsWith("https://list.jd.com/list.html?")) {
			//解析列表URL  商品URL//*[@id="plist"]/ul/li/div/div[1]/a
			try {
				Object[] evaluateXPath = rootNode.evaluateXPath("//*[@id=\"plist\"]/ul/li/div/div[1]/a");
				for (Object object : evaluateXPath) {
					TagNode aNode = (TagNode)object;
					String url = aNode.getAttributeByName("href");
					page.addUrl("https:"+url);
					
				}
			} catch (XPatherException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//获取下一页标签
			try {
				Object[] evaluateXPath = rootNode.evaluateXPath("//*[@id=\"J_bottomPage\"]/span[1]/a[10]");
				if (evaluateXPath.length>0) {
					TagNode nNode = (TagNode)evaluateXPath[0];
					String nPage = nNode.getAttributeByName("href");
					page.addUrl("https://list.jd.com"+nPage);
				}
				else {
					System.out.println("已经是最后一页了");
				}
			} catch (XPatherException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			//解析商品信息  解析商品URL
			parseProduct(page, rootNode);		
		}
		
	}
	private void parseProduct(Page page, TagNode rootNode) {
		try {
			//提取title的xpath"//div[@class=\"sku-name\"]"
			String title= Htmlutils.getText(rootNode, "//div[@class=\"sku-name\"]");
			page.addField("title", title);
			
			//获取图片的URL "//*[@id=\"spec-img\"]" "data-origin"
			String picUrl= Htmlutils.getAttrByname(rootNode, "//*[@id=\"spec-img\"]","data-origin");
			page.addField("picUrl", picUrl);
			//获取价格
			getPrice(page);
			//获取配置信息
			getSpec(page, rootNode);			
		} catch (XPatherException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 获取参数配置信息
	 * @param page
	 * @param rootNode
	 * @throws XPatherException
	 */
	private void getSpec(Page page, TagNode rootNode) throws XPatherException {
		//获取规格信息  //*[@id="detail"]/div[2]/div[2]/div[1]/div[1]
		//获取整体分类标签
		Object[] evaluateXPath3 = rootNode.evaluateXPath("//*[@id=\"detail\"]/div[2]/div[2]/div[1]/div");
		//因为数量比较多不能直接存储在hashmap里面 需要借助json 将他们转换为json数组再存
		JSONArray specArr = new JSONArray();			
		//evaluateXPath3中有多条数据 故需要迭代
		//迭代整体分类标签
		for(Object divObj : evaluateXPath3) {
			//获取大分类标签
			TagNode divNode = (TagNode)divObj;
			//过滤dl获取小分类标签
			Object[] evaluateXPath4 = divNode.evaluateXPath("/dl/dl");
			for (Object dlObj : evaluateXPath4) {
				//创建json对象
				JSONObject jsonObj = new JSONObject();
				//获取到小分类标签
				TagNode dlNode = (TagNode)dlObj;
				//获取dt dd标签内容
				Object[] dtPAth = dlNode.evaluateXPath("/dt");
				if(dtPAth.length>0) {
					TagNode dtNode = (TagNode)dtPAth[0];
					jsonObj.put("name", dtNode.getText());
				}
				Object[] ddPAth = dlNode.evaluateXPath("/dd[last()]");
				if (ddPAth.length>0) {
					TagNode ddNode  = (TagNode)ddPAth[0];
					jsonObj.put("vlaue", ddNode.getText());
				}
				//将获取到的jsonobj添加到specarr数组中
				specArr.add(jsonObj);
			}
			page.addField("spec", specArr.toString());
		}
		
		
	}
	/**
	 * 获取价格
	 * @param page
	 */
	private void getPrice(Page page) {
		//通过不同ID解析商品属性
		String dataUrl = page.getUrl();
		Pattern pattern = Pattern.compile("https://item.jd.com/([0-9]+).html");
		Matcher matcher = pattern.matcher(dataUrl);
		String goodsID=null;
		if (matcher.find()) {
			goodsID = matcher.group(1);
		}
		page.setGoodsID(goodsID);
		//获取价格  价格是通过异步请求方式写到页面上的直接查页面是查不到的只能通过对进程的检测查找
		//https://p.3.cn/prices/mgets?skuIds=J_100002749549
		//数据：[{"cbf":"0","id":"J_100002749549","m":"10000.00","op":"4288.00","p":"4288.00"}]		
		String priceContent = PageUtils.getContent("https://p.3.cn/prices/mgets?skuIds=J_"+goodsID);		
		//将获取内容转换为json对象
		JSONArray parseArr = JSONArray.parseArray(priceContent);
		if (parseArr.size()>0) {
			//取出json对象
			JSONObject jsonObj = parseArr.getJSONObject(0);
			//取出京东价格  最后转义取消价格小数点后的00
			String price = jsonObj.getString("p").replaceAll("\\.00", "");
			//System.out.println(price);	
			page.addField("price", price);
		}
	}
	

}
