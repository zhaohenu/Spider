package jredistest.SpiderDemo01;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.impl.StdSchedulerFactory;

/**
 * url调度器
 * @author zhao
 *
 */
public class UrlManage {
	public static void main(String[] args) {
		try {
			//创建一个调度器
			Scheduler defaultScheduler = StdSchedulerFactory.getDefaultScheduler();
			//开启调度器
			defaultScheduler.start();
			//指定具体任务信息
			String simpleName = UrlJob.class.getSimpleName();
			JobDetail job = new JobDetail(simpleName, Scheduler.DEFAULT_GROUP, UrlJob.class);
			//最后时间的规则  代码是指三秒执行一次 也可以设为其他值 比如定时每天执行一次
			CronTrigger cron = new CronTrigger(simpleName, Scheduler.DEFAULT_GROUP,"*/3 * * ? * * ");
			//
			defaultScheduler.scheduleJob(job, cron);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
