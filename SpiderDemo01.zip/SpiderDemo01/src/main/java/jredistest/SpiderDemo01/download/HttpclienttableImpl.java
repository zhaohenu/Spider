package jredistest.SpiderDemo01.download;
/**
 * 页面对象  存储下载的信息 方便别的类调用获取
 */

import jredistest.SpiderDemo01.domain.Page;
import jredistest.SpiderDemo01.utils.PageUtils;

public class HttpclienttableImpl implements Downloadable {

	@Override
	public Page download(String url) {
		Page page = new Page();
		page.setContent(PageUtils.getContent(url));
		page.setUrl(url);
		return page;
	}

}
