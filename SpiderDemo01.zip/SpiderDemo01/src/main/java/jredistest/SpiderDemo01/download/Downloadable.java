package jredistest.SpiderDemo01.download;

import jredistest.SpiderDemo01.domain.Page;

/**
 * 下载功能相关接口
 * @author zhao
 *
 */
public interface Downloadable {
	Page download(String url);

}
