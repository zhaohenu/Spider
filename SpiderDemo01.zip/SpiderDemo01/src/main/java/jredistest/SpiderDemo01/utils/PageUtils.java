package jredistest.SpiderDemo01.utils;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * 页面内容获取工具类
 * 
 * @author zhao
 *
 */
public class PageUtils {
	public static String getContent(String url) {
		String result = null;
		// 使用httpclients创建一个构建器
		HttpClientBuilder builder = HttpClients.custom();
		// 获取httpclient 这两步是固定的写法 有工具创建者规定
		// httpclient就是模拟正常上网请求的 故可以用它来实现爬取网络数据
		CloseableHttpClient httpClient = builder.build();
		try {
			// 网页请求
			HttpGet get = new HttpGet(url);
			// 执行get请求 获取指定URL页面的内容
			// 请求页面内容存放在response中
			CloseableHttpResponse response = httpClient.execute(get);
			// 解析页面内容
			result = EntityUtils.toString(response.getEntity());

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

}
