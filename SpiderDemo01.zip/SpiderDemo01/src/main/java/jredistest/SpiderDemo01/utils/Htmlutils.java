package jredistest.SpiderDemo01.utils;

import org.htmlcleaner.TagNode;
import org.htmlcleaner.XPatherException;

public class Htmlutils {
	/**
	 * 获取标签中的内容
	 * @param node
	 * @param xpath
	 * @return
	 */
	public static String getText(TagNode node ,String xpath) {
		String result=null;
		Object[] evaluateXPath;
		try {
			evaluateXPath= node.evaluateXPath(xpath);
			if (evaluateXPath.length>0) {
				//将其强转才能操作里面的数据
				TagNode titlenode= (TagNode)evaluateXPath[0];	
				//result获取指定内容  trim 去掉字符串首尾的空格
				result=titlenode.getText().toString().trim();
			}
		} catch (XPatherException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 根据属性名获取属性的值
	 * @param node
	 * @param xpath
	 * @param attr
	 * @return
	 */
	public static String getAttrByname(TagNode node,String xpath,String attr) {
		String result=null;
		//获取图片的URL  "//*[@id=\"spec-img\"]"
		Object[] evaluateXPath2;
		try {
			evaluateXPath2= node.evaluateXPath(xpath);
			if (evaluateXPath2.length>0) {
				TagNode picNode =(TagNode)evaluateXPath2[0];				
				String picUrl = picNode.getAttributeByName(attr);
				result="https:"+picUrl;		
			}
		} catch (XPatherException e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
