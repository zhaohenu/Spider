package jredistest.SpiderDemo01.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 页面实体类 存放页面所有信息
 * @author zhao
 *
 */


public class Page {
	/**
	 * 页面内容
	 */
	private String content;
	/**
	 * 存放页面的URL
	 */
	private String url;
	/**
	 * 商品的ID
	 */
	private String goodsID;
	/**
	 * 存放临时解析的URL
	 */
	private List<String> urls = new ArrayList<String>();
	

	HashMap<String, String> values = new HashMap<String, String>();
	
	//content
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	public void addField(String field,String value) {
		this.values.put(field, value);
		
	}
	public HashMap<String, String> getValus(){
		return this.values;
	}
	//URL
	public String getUrl() {
		return url;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	//商品ID
	public String getGoodsID() {
		return goodsID;
	}

	public void setGoodsID(String goodsID) {
		this.goodsID = goodsID;
	}
	

	public List<String> getUrls() {
		return urls;
	}
	//临时解析的URLs
	public void addUrl(String url) {
		this.urls.add(url);	
	}
	

	

}
