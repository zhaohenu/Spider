package jredistest.SpiderDemo01;

import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import jredistest.SpiderDemo01.utils.RedisUtils;
import redis.clients.jedis.Jedis;

public class UrlJob implements Job{

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		//获取jedis连接
		Jedis jedis = RedisUtils.getJedis();
		List<String> urlList = jedis.lrange("startUrl", 0, -1);
		for (String url : urlList) {			
			jedis.lpush("urlList", url);
		}
		System.out.println("定时任务执行了");
		
	}

}
