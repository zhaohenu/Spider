package jredistest.SpiderDemo01.repository;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class QueueRepositoryImpl implements Repository {
	//声明一个数据仓库queue
	private Queue<String> queue = new ConcurrentLinkedQueue<String>();
	@Override
	public void add(String url) {
		this.queue.add(url);
	}

	@Override
	public String poll() {
		return this.queue.poll();
	}

}
