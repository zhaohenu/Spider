package jredistest.SpiderDemo01.repository;

import java.util.HashMap;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

import jredistest.SpiderDemo01.utils.DomainUtils;


/**
 * 随机获取数据
 * 爬虫分布式爬取
 * @author zhao
 *
 */
public class RandomQueueRepositoryImpl implements Repository{
	
	
	HashMap<String, Queue<String>> hashMap = new HashMap<String,Queue<String>>();
	@Override
	public void add(String url) {
		//	判断url是属于哪个队列的，其实就是获取url中的顶级域名
		String topDomain = DomainUtils.getTopDomain(url);
		Queue<String> queue = hashMap.get(topDomain);
		if(queue==null) {
			queue = new ConcurrentLinkedQueue<String>();
		}
		queue.add(url);
		hashMap.put(topDomain, queue);
	}

	@Override
	public String poll() {
		String[] keys = hashMap.keySet().toArray(new String[0]);
		Random random = new Random();
		int nextInt = random.nextInt(keys.length);
		Queue<String> queue = hashMap.get(keys[nextInt]);
		return queue.poll();
	}

}
