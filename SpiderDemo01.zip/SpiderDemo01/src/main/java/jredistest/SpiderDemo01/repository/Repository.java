package jredistest.SpiderDemo01.repository;

public interface Repository {
	void add(String url);
	String poll();

}
