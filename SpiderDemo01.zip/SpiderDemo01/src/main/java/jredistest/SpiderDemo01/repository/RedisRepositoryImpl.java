package jredistest.SpiderDemo01.repository;

import jredistest.SpiderDemo01.utils.RedisUtils;
import redis.clients.jedis.Jedis;

public class RedisRepositoryImpl implements Repository {
	public String urlList = "urlList";
	@Override
	public void add(String url) {
		//获取jedis连接
		Jedis jedis = RedisUtils.getJedis();
		//向jedis中添加URL
		jedis.lpush(urlList, url);
		
		RedisUtils.returnResource(jedis);
		jedis.close();
	}

	@Override
	public String poll() {
		Jedis jedis = RedisUtils.getJedis();
		
		String string = jedis.rpop(urlList);
		
		RedisUtils.returnResource(jedis);
		jedis.close();
		return string;
	}

}
