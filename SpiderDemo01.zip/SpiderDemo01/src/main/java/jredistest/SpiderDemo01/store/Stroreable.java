package jredistest.SpiderDemo01.store;

import jredistest.SpiderDemo01.domain.Page;

/**
 * store的接口
 * @author zhao
 *
 */
public interface Stroreable {

	void store(Page page);

}
