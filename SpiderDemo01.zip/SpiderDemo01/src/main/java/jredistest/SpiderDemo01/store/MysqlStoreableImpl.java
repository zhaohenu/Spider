package jredistest.SpiderDemo01.store;

import java.util.Date;

import jredistest.SpiderDemo01.domain.Page;
import jredistest.SpiderDemo01.utils.MyDateUtils;
import jredistest.SpiderDemo01.utils.MyDbUtils;

/**
 * mysql数据库存储实现类
 * @author zhao
 *
 */
public class MysqlStoreableImpl implements Stroreable{

	@Override
	public void store(Page page) {
		//goods_id,data_url,pic_url,title,price,param,`current_time`
		String goodsID = page.getGoodsID();
		String dataUrl = page.getUrl();
		String picUrl = page.getValus().get("picUrl");
		String title = page.getValus().get("title");
		String price = page.getValus().get("price");
		String params = page.getValus().get("spec");
		String curr_time = MyDateUtils.formatDate2(new Date());
		MyDbUtils.update(MyDbUtils.INSERT_LOG, goodsID,dataUrl,picUrl,title,price,params,curr_time);
	}

}
