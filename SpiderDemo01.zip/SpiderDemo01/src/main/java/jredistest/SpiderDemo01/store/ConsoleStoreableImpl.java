package jredistest.SpiderDemo01.store;

import jredistest.SpiderDemo01.domain.Page;
/**
 * 控制台存储实现类
 * @author zhao
 *
 */
public class ConsoleStoreableImpl implements Stroreable{

	@Override
	public void store(Page page) {
		System.out.println(page.getUrl()+"--价格: "+page.getValus().get("price"));
	}
	

}
