package jredistest.SpiderDemo01;

import org.junit.Test;

import jredistest.SpiderDemo01.domain.Page;
import jredistest.SpiderDemo01.download.HttpclienttableImpl;
import jredistest.SpiderDemo01.process.JDProcessableImpl;
import jredistest.SpiderDemo01.store.MysqlStoreableImpl;

public class SpiderTest {
	
	@Test
	public void testSpider() throws Exception {
		//获取爬虫程序
		Spider spider = new Spider();
		//給downloadable接口赋予一个实现类
		spider.setDownloadable(new HttpclienttableImpl());	
		//给解析接口设置实现类
		spider.setProcess(new JDProcessableImpl());
		//给存储接口赋予一个实现类
		spider.setStroreable(new MysqlStoreableImpl());
		
		//执行爬虫程序
		//spider.start();
		//实现具体功能
		String url = "https://list.jd.com/list.html?cat=9987,653,655&page=141&sort=sort_rank_asc&trans=1&JL=6_0_0&ms=10#J_main";
		
		Page page = spider.download(url);
		
		spider.process(page);
		spider.store(page);
	}

}
