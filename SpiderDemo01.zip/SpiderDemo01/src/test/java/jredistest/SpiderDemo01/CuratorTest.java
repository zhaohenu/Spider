package jredistest.SpiderDemo01;

import java.net.Inet4Address;
import java.net.InetAddress;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs.Ids;
import org.junit.Test;

public class CuratorTest {
	@Test
	public void curatorTest() throws Exception {
		//获取zk的链接
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);//获取zk链接的一个重试策略
		String zookeeperConnectionString ="192.168.32.120:2181,192.168.32.121:2181,192.168.32.122:2181";//在此指定zk的节点信息
		int sessionTimeoutMs = 5000;  //连接失效时间  即连接关闭以后  失效的时间  在4秒到40秒之间
		int connectionTimeoutMs = 3000;  //连接超时时间 
		CuratorFramework client = CuratorFrameworkFactory.newClient(zookeeperConnectionString, sessionTimeoutMs, connectionTimeoutMs, retryPolicy);
		client.start();
		
		
		//获取本机IP
		InetAddress localHost = InetAddress.getLocalHost();
		String ip = localHost.getHostAddress();
		/*
		//创建一个父节点
		client.create()
			.withMode(CreateMode.PERSISTENT) //建立节点的类型 永久节点
			.withACL(Ids.OPEN_ACL_UNSAFE) //设置安全策略类型
			.forPath("/monitor");  //设置节点的路径 */
		//创建子节点 如果父节点不存在的话 直接创建父节点
		client.create()
			.creatingParentsIfNeeded()  //如果父节点不存在则创建父节点
			.withMode(CreateMode.PERSISTENT)  //创建临时节点
			.withACL(Ids.OPEN_ACL_UNSAFE)
			//每一个节点都是有序的所以各不相同 加上本机IP可以具体分析节点所代表的机器
			.forPath("/monitor/"+ip);  //创建子节点
		
	}

}
